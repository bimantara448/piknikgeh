$(document).ready(function(){
	jQuery('.item-bookmark').on('click',function(){
		jQuery('.item-bookmark').toggleClass('active');
	});
});